/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CMSClass;

/**
 *
 * @author Franchesca Shanne
 */
public class Offer extends CondoData{
    private final String[] _offer = {"SELL", "RENT"};
    
    public void replaceValue(int index, int offer){
        _data.set(index, _offer[offer]);
    }
    
    @Override
    public void replaceValue(int index, String offer){
        _data.set(index, offer);
    }
    
    public void replaceValue(int index){
        int offer = 0;
        if(_data.get(index) == null ? _offer[0] == null : _data.get(index).equals(_offer[0])){
            offer = 1;
        }
        _data.set(index, _offer[offer]);
    }
}
